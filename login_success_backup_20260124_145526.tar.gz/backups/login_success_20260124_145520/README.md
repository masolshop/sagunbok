## 로그인 성공 백업 - Sat Jan 24 14:55:20 UTC 2026

### 백업 내용
- Auth.tsx (v6.2.8 API URL + 캐시 방지)
- AdminView.tsx (v6.2.8 API URL)
- APPS_SCRIPT_V6.2.8_CORRECT_COLUMNS.js (최종 버전)
- dist/ 폴더 (빌드 결과물)

### Apps Script URL
https://script.google.com/macros/s/AKfycbyULZORS2SzTBYYTK_r_5Kd5Q-I3nELI4RbDim1THqGIX8IT0PiAL-BL2oqomf16ate/exec

### Spreadsheet ID
1NzBVwAjDTSQWznBapoD1fGspUvXpvQsozdJVSEF5Atc

### 배포 위치
- EC2: /var/www/sagunbok/
- URL: http://3.34.186.174/

### 시트 구조
모든 시트(기업회원, 컨설턴트, 매니저) I열(인덱스 8) = 승인여부

### 테스트 계정
- 전화번호: 01063529091
- 비밀번호: 12345
- 회사: 페마연
